import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import {
    FiMenu,
    FiSearch,
    FiUser,
    FiLogOut,
    FiVideo
} from "react-icons/fi";

import { useAuth } from "../context/AuthContext";

const Header = () => {
    const [search, setSearch] = useState("");
    const navigate = useNavigate();
    const { user, logout } = useAuth();

    const handleSearch = (e) => {
        e.preventDefault();

        if (search.trim()) {
            navigate(`/search?q=${encodeURIComponent(search)}`);
        }
    };

    const handleLogout = () => {
        logout();
        navigate("/login");
    };

    return (
        <header className="header">

            <div className="header-left">
                <button className="menu-btn">
                    <FiMenu size={24} />
                </button>

                <Link to="/" className="logo">
                    YouTube
                </Link>
            </div>

            <form className="search-box" onSubmit={handleSearch}>
                <input
                    type="text"
                    placeholder="Search"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />

                <button type="submit">
                    <FiSearch size={22} />
                </button>
            </form>

            <div className="header-right">

                {user ? (
                    <>
                        <Link to="/upload" className="upload-btn">
                            <FiVideo />
                            Upload
                        </Link>

                        <button
                            className="logout-btn"
                            onClick={handleLogout}
                        >
                            <FiLogOut />
                            Logout
                        </button>
                    </>
                ) : (
                    <Link to="/login" className="login-btn">
                        <FiUser />
                        Login
                    </Link>
                )}

            </div>

        </header>
    );
};

export default Header;